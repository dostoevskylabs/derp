#!/bin/bash
/usr/share/metasploit-framework/tools/exploit/pattern_offset.rb -q "$1"
